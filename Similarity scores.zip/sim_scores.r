# This code computes similarity scores for context and target expressions represented 
# by averaging (resultAV.csv) and PCA (resultPCA.csv), as well as for individual words in 
# expressions and context represented with PCA (resultPCA[1-5].csv).

# Install and load necessary packages.
install.packages("lsa", repos="http://cran.rstudio.com/")
install.packages("pracma", repos="http://cran.rstudio.com/")
library("lsa")
library("pracma")

cat("Please, answer the following questions.\n")

# Enter pathway to your input files.
# Ex.: /.../filename.csv

cat("Please, specify the full pathway to the input file for target expressions:\n")
fpath_target <- readLines("stdin", n=1)

# number of context instances
cat("How many context instances per an expression do you have?\n")
rows <- readLines("stdin", n=1)

# max number of embeddings per expression 
cat("What is the maximum number of embeddings per an expression?\n")
columns <- readLines("stdin", n=1)

# vector dimensionality
cat("What is the dimensionality of your vectors?\n")
dims <- readLines("stdin", n=1)

# directory with context files folders
cat("Please, specify the full path to the directory containing folders with files for context:\n")
context_dir <- readLines("stdin", n=1)

# Upload matrix with embeddings for target expressions: constituent vectors are in rows, 
# one full vector per cell.
phrases<-read.csv(fpath_target, header=F, sep=",", row.names=1)

# *** Defining functions ***

# Prepare matrices with vectors in columns and a single value in each cell
prepare.matrix <- function(mtx, dims){
	numbermt <- matrix(nrow = dims, ncol = nrow(mtx))
	for (j in 1:nrow(mtx)) {
		numbermt[,j]<-as.numeric(unlist(strsplit(as.character(mtx[j,]), ",")))
		}
	return(numbermt)
}


# prepare matrices for phrases
matrix.phrase <- function(phrase, length){
	mt <- matrix(nrow = dims, ncol= length)
	vec <- numeric()
	for (k in 1:length){
		vec <- as.numeric(unlist(strsplit(as.character(phrase[1,k]),",")))
		mt[,k] <- vec	
	}	
	return(mt)
}


# Find orthonormal basis of a linear subspace
find.basis <- function(mtx){
	PCA<-prcomp(mtx)
	#summary(PCA) # importance of PCs
	subspace<-PCA$x[,1:3] # small matrix 
	basis<-orth(subspace) # similar functions are qr() and gramSchmidt()
	return(basis)
}


# Find an average vector
average.vector <- function(matrx) {
	avvector <- as.vector(rowSums(matrx)) 
	return(avvector)	
}


# Find similarity scores of target words with the context represented with PCA
sim.scores.pca <- function(orth_basis, phrase){
 	scores <- numeric(0)
	for (i in 1:phrase_length)
	{
			word <- as.numeric(unlist(strsplit(as.character(phrase[[i]]),",")))
			orth_basis <- matrix(unlist(orth_basis), dims, columns)
			p <- (orth_basis %*% t(orth_basis)) %*% word
			score <- cosine(word,p)
			scores <- c(scores, score)
	}
	return(scores)
}

# Performing PCA on phrase matrices
phrase.pca <- function(orth_basis, phrasemt){
	phrasePCA <- prcomp(phrasemt)
	PC_phrase <- phrasePCA$x[,1]
	projection <- (orth_basis %*% t(orth_basis)) %*% PC_phrase
	score <- cosine(as.vector(projection), as.vector(PC_phrase))
	return(score)
}

#	***


# Calculate similarity scores for each word in the phrase.
# Outputs a matrix per expression.

all_av_scores = all_pca_scores = matrix(0,rows,nrow(phrases))
colnames(all_av_scores) <- rownames(phrases)

for (k in 1:nrow(phrases)) 
	{
		phrase_length <- length(phrases[k,][mapply(grepl,",",phrases[k,]) == T])
		filenames <- list.files(paste(context_dir, "/", k, sep=""), full.names=TRUE)
		matrices <- lapply(filenames,read.csv)
		ready_matrices <- lapply(matrices, prepare.matrix, dims)
		orth_bases <- lapply(ready_matrices, find.basis)
		
		av_context <- lapply(ready_matrices, average.vector)
		phrase_mt <- matrix.phrase(phrases[k,], phrase_length)
		
		pca_scores <- unlist(lapply(orth_bases, phrase.pca, phrase_mt))
		all_pca_scores[,k] <- pca_scores 
		
		av_phrase <- average.vector(phrase_mt)
		av_scores <- unlist(lapply(av_context, cosine, av_phrase))
		all_av_scores[,k]<- av_scores
		
		resultPCA <- lapply(orth_bases, sim.scores.pca, phrases[k,])
		resultPCA <- matrix(unlist(resultPCA), rows, phrase_length)
		write.csv(resultPCA, file = paste(context_dir, "/resultPCA", k, ".csv", sep=""), quote=TRUE)
	}
	
write.csv(all_av_scores, file = paste(context_dir, "/resultAV", ".csv", sep=""))
write.csv(all_pca_scores, file = paste(context_dir, "/resultPCA", ".csv", sep=""))
	
# 						*	*	*


